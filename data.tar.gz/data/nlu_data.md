<!--- Make sure to update this training data file with more training examples from https://forum.rasa.com/t/grab-the-nlu-training-dataset-and-starter-packs/903 --> 




## intent:greet
- Hi
- Hey
- Hi bot
- Hey bot
- Hello
- Good morning
- hi again
- hi folks
- hi Mister
- hi pal!
- hi there
- greetings
- hello
- hello robot
- hey robot
- heyy
- namaste
- namskar
- namaskaar
- naamaste

## intent: chitchat
- None of your business
- chup kar
- fuck off
- fuckoff
- abc
- what do you mean


## intent: stop
- stop

## intent: outsource
- outsource
- out sourced
- outsrcd
- out

## intent: inhouse
- in
- inhouse
- inhs



## intent: goodbye
- goodbye
- bye
- bye bye



## intent:thank
- Thanks
- Thank you
- Thank you 
- Thanks bot
- Thanks for that
- cheers
- cheers bro
- ok thanks!
- shukria
- dhanyawad
- dhanyawaad
- sukriya

## intent:affirm
- yes
- yepp
- yepp
- yuss
- yes sure
- absolutely
- for sure
- yes yes yes
- yes
- yepp
- yeah
- yepp
- haa
- haan
- haanji
- bilkul
- sahi baat
- aji haa
- jii haan
- ji haa


## intent:inform
- 7838930304
- 9414485068
- my number is 9489785068
- its 9834367345
- my reference number is 9414904068
- my number is 8967556347
- 7878450304
- 9419056068
- my number is 9414485968
- its 8765167345
- my reference number is 9445673468
- my number is 8967556347
- 7838930304
- 9414485068
- my number is 941263958
- its 9841737345
- my reference number is 9419985068
- my number is 8967616347
- my id is 9414077395
- its 7838930304
- i am from kota
- father mother sister her husband a nephew and my girlfriend
- yaa he advises me on things
- my office is in ghatkopar
- yes we have around 30 employees.
- we have been here for the last 6 months.
- we have a clothes shop. my wife is the fashion designer i market them
- i stay in worli
- i live in dadar
- my house is in panvel
- i stay in rajasthan
- mumbai
- ahemadabad
- gujrat
- i stay in worli
- i live in dadar
- my house is in panvel
- i stay in rajasthan
- mumbai
- ahemadabad
- gujrat- i stay in worli
- i live in dadar
- my house is in panvel
- i stay in rajasthan
- mumbai
- ahemadabad
- gujrat
- i stay in Palava
- 3
- 4
- 102
- 33
- 24
- 500
- worli
- dadar
- say
- what
- can you?
- there are 4 members in my family. My parents my sister and myself.
- my parents and one sister
- parents and two brothers
- 5 members in the family
- wife and three children
- three members
- ihave 6 members in my family
- there are 5 members in my family.
- my brothers are also involved in the business
- one of my brother manages some work
- yes he handles the finances and i handle the daily mamagement.
- yaa he manages the daily affairs sits on shop.
- by father helps me alot somethimes my cousins also chip in
- its located in prabhadevi
- i have 10 employees
- 9975701240
- in colaba
- three
- we make fools out of people
- its in malabar
- we have 125 cr employees but we work with some lacks
- since last 3 months
- last 300 years
- its 7838930304
- i stay in gharkopar
- i have one sister and my parents. sister is married stays in holland
- yes we make carpets and export it to the US
- its in marol
- yes i havbe 45 emplyees. all of them are on wages.
- its been 10 years now.
- we have been in this one for the last 25 months.
- 1 cr
- crossed 1 cr already.
- 7838930304
- 9414485068
- my number is 9489785068
- its 9834367345
- my reference number is 9414904068
- my number is 8967556347
- 7878450304
- 9419056068
- my number is 9414485968
- its 8765167345
- my reference number is 9445673468
- my number is 8967556347
- 7838930304
- 9414485068
- my number is 941263958
- its 9841737345
- my reference number is 9419985068
- my number is 8967616347
- my id is 9414077395
- its 7838930304
- i am from kota
- father mother sister her husband a nephew and my girlfriend
- yaa he advises me on things
- my office is in ghatkopar
- yes we have around 30 employees.
- we have been here for the last 6.
- we have a clothes shop. my wife is the fashion designer i market them
- i stay in worli
- i live in dadar
- my house is in panvel
- i stay in rajasthan
- mumbai
- ahemadabad
- gujrat
- i stay in worli
- i live in dadar
- my house is in panvel
- i stay in rajasthan
- mumbai
- ahemadabad
- gujrat- i stay in worli
- i live in dadar
- my house is in panvel
- i stay in rajasthan
- mumbai
- ahemadabad
- gujrat
- i stay in Palava
- 3
- 4
- 102
- 33
- 24
- 500
- worli
- dadar
- say
- what
- can you?
- there are 4 members in my family. My parents my sister and myself.
- my parents and one sister
- parents and two brothers
- 5 members in the family
- wife and three children
- three members
- ihave 6 members in my family
- there are 5 members in my family.
- my brothers are also involved in the business
- one of my brother manages some work
- yes he handles the finances and i handle the daily mamagement.
- yaa he manages the daily affairs sits on shop.
- by father helps me alot somethimes my cousins also chip in
- its located in prabhadevi
- i have 10 employees
- 9975701240
- in colaba
- three
- we make fools out of people
- its in malabar
- we have 125 cr employees but we work with some lacks
- since last 3
- last 300
- its 7838930304
- i stay in gharkopar
- i have one sister and my parents. sister is married stays in holland
- yes we make carpets and export it to the US
- its in marol
- yes i havbe 45 emplyees. all of them are on wages.
- its been 10 now.
- we have been in this one for the last 25.
- 1
- crossed 1 already.
- its 7838930304
- this this is the dirsctor and this this is the shareholding pattern
- its been 13
- its in haryana
- we have 3 machines
- 2000 tonnes and 70 pc
- 67 workers in total
- 3 parties abc, dfg and xcw.
- we give in 30 days
- have to pay 30 cr in market
- some what two months
- in bhiwandi close to the main factory. its owned.
- yes there are numerous custiomers.
- around 60 days
- have to receive some 40 cr
- some 3 cr
- around 50 cr
- mostly in bank after gst.
- 13 pc
- 67 emplyees
- we r in the 4 pc bracket
- for 3 cr
- planning to start a new unit at manesar.
- i have x y and z parties and they have w,e,r sharehiolding
- 13 years till now
- retail
- stockist
- there are these three parties i purchase from
- three months
- 3.4 cr
- its near the locations
- i am a retialer.
- its 90 days.
- 2.3 cr
- 30 cr pm
- 3
- 90 pc
- 28 pc
- 78 employess
- 14 pc
- 30 lacks
- to increase productiopn.
- it is 7838930304
- private
- mahesh majrekra and sanjay gupta. all three of us have 33 pc each.
- its been 13 years
- groceries
- retail
- stockist
- i purchase from three parties, this this ans this
- we receive the payments in 45 days
- some 30
- we have stocks for 30 days
- its is near factory
- we sell to 4 parties, this this and ths
- 90 days
- we have to receive some 3 lacks from the debtors
- we do some 13 lacks
- its around 2.5 cr
- its about 78%
- 23 pc
- we have 45 emplyees
- they are 18 pc
- 8 cr
- we have to put one new unit.
- it is 7838930304
- mahesh majrekra and sanjay gupta. all three of us have 33 pc each.
- its been 13 years
- groceries
- retail
- stockist
- i purchase from three parties, this this ans this
- we receive the payments in 45 days
- some 30
- we have stocks for 30 days
- its is near factory
- we sell to 4 parties, this this and ths
- 90 days
- we have to receive some 3 lac from the debtors
- we do some 13 lacks
- its around 2.5 cr
- its about 78 %
- 23 pc
- we have 45 emplyees
- they are 18 pc
- 8
- we have to put one new unit.
- its 7838930304
- its have been 12
- i ahve been in this business since forever. worked with my father before.
- textiles
- its in jabalpur, near bedaghat.
- we have some staff there, i also vist sometimes a month.
- we have some 23 machines
- 67 workers are there.
- 50k
- 100k
- 20k
- 50 k
- 20 k
- lacw
- 20 lacws
- wip
- it is wip
- month
- month or two
- three months
- year and beyond
- we have a capacity of 23 yarns per day and we utilize all of it.
- we purchase raw materials from welspun.
- we pay in 90
- we have to pay some 34 to welspun
- we have stock for 120 days at any point in time.
- we sell to lots of retailers across india.
- we offer a credit period of 45. days
- very samll amount is outstanding. we receive payments on time.
- we sell about 25 worth of goods every month.
- we have done some 4 and are expecting to finish year on 6+cr
- not more than 20 pc
- we work on around 18 pc returns
- total 67 employees
- 18 pc
- 35 lacks
- i want to start another manufacture unit.
- clothes
- cloth
- textile
- 1
- 2
- 3
- 4
- 5
- 6
- 7
- 8
- 9
- 10 
- something
- this and this
- was studying
- 1pc
- 12cr
- 12pc
- 19pc
- fun
- somehow
- new nothing
- here and there
- thane
- chichpokli
- varanasi
- jabalputr
- lokhandwala
- vadala
- andheri
- ahemedabad
- fmcg
- fmcg
- fmcg
- textile
- clothe 
- clothes 
- electronics goods 
- electonic
- vegetables
- paint
- stone
- marble
- paper mill
- groceries
- 56 lacw
- flipkart
- mai worli me rehta hu
- mai kolaba me rehta hu
- mera ghar lohandwala me hai
- mere mata pita or behen k saath rehta hu
- meri wife or bacchon k saath rehta hu
- mera poora pariwar saath me worli me rehta hai
- 89pc
- 14pc 
- 10pc
- 9414060767
- ya mr dash dash and mr gdash gdash are the partners along with me. we have equal shares
- we have been here for some seven and a half years
- electronics
- its in gujrat
- one of us visits evrey week
- one machine we haveits a big one
- three ppl handle the one machine
- its can produce 300 gadgets per day and we use it all
- we buy raw material from the port in gujrat
- we pay in 90 days
- we have to pay some 34 lacks to our creditors on the book
- for about a month
- we sell our products in all of north india. Delhi is tghe major buyer.
- we offer payment terms of 45 days not anything more
- receivables are noth of a crore
- aroubd 30 lacks
- we have done some 3.5 cr till now and are planning to touch 7 cr by the end of this year
- about 75 pc
- we work on 25 pc margins, at the least.
- 12
- 14pc
- aroubd 25 lacks
- will set up a new machine
- 7737518038
- i qon 20 pc shares
- the company got incorporated in 1999
- we are into cements
- the unit is in bihar
- there is a big work force abnd manager at the site they manage and report to em
- its a big plants and many machines
- 230 orkers
- we can create 200 tonnes of cement per wk, we do around 100 tonnes
- we purchase rawmaterial from chine
- 90 days
- must be aroubnd 10 cr we work around that 
- 6 months
- our major buyer is the indian government
- 60 days
- 300 crores
- around 70-80 cr
- we turnover at aroubnd 300-400 crores
- we are public it doesnt matter wthr cash or not
- around 14 pc
- 345
- 14 pc
- we will pay in frb
- 15 cr
- we want to set up a small new plant
- 7838930304
- mr bhatia with 34 pc and mr sharma with 10 pc
- i have been here for the last 4-5 years
- textiles
- its in jabalpur
- i travel once a week
- 3 machines
- 45 workers
- we have total capacity of 3 tonnes we produce 1.5 tonnes
- three parties, reliance and gm
- we collect in 90 days
- we have to receive some 1 cr from the market
- we maintain stock levels for 30 days
- we have one buyer, hdfc bank.
- we get our payments in 30 days max.
- market owes us 2 cr
- we sell some 34 lac worth of stuff
- it is around 34 cr annual
- its about 30 pc
- our margins are 22 pc
- 67 employees inclusing me as well
- 12 pc 
- paid
- 15 cr
- we want to put up new shop at andheri
- something
- this this
- this and this
- this and this
- this and this
- so so doubts
- doubts and doubts
- business
- some other job



## intent:deny
- no 
- No
- nah
- Nope
- noi
- no
- noi
- nope
- nahh
- nana
- no
- nahi
- ji nahin
- jii nahi
- naa 


## intent:prop
- proprietership
- proprity
- i am proprieter
- its proprietership
- prop
- properteship
- propertiship
- propreitership
- its properteship
- it is propertiship
- it is propreitership
- its properiteship

## intent:private
- private
- it's private
- private
- pvt
- it is private
- private
- its private ltd

## intent:public
- its public
- public
- public
- public
- it is public
- pub
- publik
- public ltd
- public

## intent:partnership
- its partnership
- partnership
- partnership
- partnership
- partner
- patner
- pship
- p'ship
- partnerr
- partnership
- patnershi
- its partnership


## intent:manufacturing
- manufacturing
- manu
- mnufctr
- manufacturing
- manufacturing

## intent:trader
- trader
- retail
- wholesale
- retail and wholesale
- shop
- shopkeeper
- dukaan
- showroom

##intent: SP
- service
- service provider
- service based
- job
- handicraft
- job work
- sp
- SP
- sp
- sp 
- SP



## intent:public
- public
- pub
- publik


## intent: repeat
- what
- what?
- repeat
- pardon
- can you say that again
- can you please repeat
- repeat please
- i did not understand
- not understood
- what?
- whatt??
- i didnt get it


## intent: fmcg
- fmcg
- fmcg
- FMCG

## intent: garments
- garments
- gaments
- clothes

## intent: footwear
- footwear
- foowear
- shoes

## intent: chemicals
- chemicals
- chemic
- chemical











