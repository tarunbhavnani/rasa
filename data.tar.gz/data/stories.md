
## Generated Story 6001496072145186830
* greet
    - action_interview_start
    - followup{"name": "action_listen"}
    - slot{"counter": "action_interview_start"}
    - slot{"current": "action_interview_start"}
* inform
    - action_default_fallback
    - followup{"name": "action_fetch_details"}
    - action_fetch_details

